import React from 'react';
import '../styles/footer.css';

const Footer = () => {
  return (
    <footer className="footer-section" id="footer">
      <div className="footer-container">
        <div className="footer-content">
          <div className="footer-brand">
            <div className="footer-logo">
              <span className="logo-text">EL</span>
              <span className="logo-name">Ezekiel Labay</span>
            </div>
            <p className="footer-tagline">
              Senior Software Engineer & Graphic Designer crafting exceptional digital experiences.
            </p>
          </div>
          
          <div className="footer-links">
            <div className="links-column">
              <h3 className="links-title">Contact</h3>
              <a href="mailto:hello@example.com" className="footer-link">hello@example.com</a>
              <a href="tel:+1234567890" className="footer-link">+1 (234) 567-890</a>
              <span className="footer-link">Based in San Francisco, CA</span>
            </div>
            
            <div className="links-column">
              <h3 className="links-title">Follow</h3>
              <a href="#" className="footer-link">LinkedIn</a>
              <a href="#" className="footer-link">Dribbble</a>
              <a href="#" className="footer-link">GitHub</a>
              <a href="#" className="footer-link">Instagram</a>
            </div>
          </div>
        </div>
        
        <div className="footer-bottom">
          <p className="copyright">
            © {new Date().getFullYear()} Ezekiel Labay. All rights reserved.
          </p>
          <div className="footer-cta">
            <button className="btn-primary">
              Let's Work Together
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" style={{ marginLeft: '8px' }}>
                <path d="M22 2L11 13M22 2L15 22L11 13M22 2L2 9L11 13" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;