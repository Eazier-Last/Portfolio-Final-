import React from 'react';
import '../styles/header.css';

const Header = () => {
  return (
    <header className="main-header">
      <div className="header-container">
        <div className="header-logo">
          <span className="logo-text">EL</span>
          <span className="logo-name">Ezekiel Labay</span>
        </div>
        
        <nav className="header-nav">
          <a href="#home" className="nav-link active">Home</a>
          <a href="#portfolio" className="nav-link">Posters</a>
          <a href="#logo-designs" className="nav-link">Logo Designs</a>
          <a href="#skills" className="nav-link">Skills</a>
          <a href="#footer" className="nav-link">Contact</a>
        </nav>
      </div>
    </header>
  );
};

export default Header;