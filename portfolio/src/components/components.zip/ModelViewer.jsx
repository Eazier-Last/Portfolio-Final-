import React, { useRef } from 'react';
import { useGLTF } from '@react-three/drei';
import * as THREE from 'three';

function ModelViewer({ modelPath, scale = 1, position = [0, 0, 0], color }) {
  const group = useRef();
  const { scene } = useGLTF(modelPath);
  
  // Clone the scene to avoid issues with multiple instances
  const modelScene = React.useMemo(() => scene.clone(), [scene]);
  
  // Apply custom material if needed
  React.useEffect(() => {
    modelScene.traverse((child) => {
      if (child.isMesh) {
        // You can customize materials here
        child.castShadow = true;
        child.receiveShadow = true;
        
        // Optionally apply a color tint
        if (color && child.material) {
          const newMaterial = child.material.clone();
          if (newMaterial.color) {
            newMaterial.color.multiplyScalar(1.2); // Brighten slightly
          }
          child.material = newMaterial;
        }
      }
    });
  }, [modelScene, color]);

  return (
    <primitive 
      ref={group}
      object={modelScene}
      scale={scale}
      position={position}
    />
  );
}

// Preload models for better performance
export default React.memo(ModelViewer);